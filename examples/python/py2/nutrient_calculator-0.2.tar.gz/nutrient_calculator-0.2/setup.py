try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

config = {
    'description': 'Nutrient Calculator for Lauren',
    'author': 'Andres Kroker, Jacob George',
    'url': 'NA',
    'download_url': 'NA',
    'author_email': 'akroker@ucalgary.ca',
    'version': '0.2',
    'install_requires': ['nose','setuptools'],
    'packages': ['nutrient_calculator','nutrient_calculator.consumables','nutrient_calculator.csv','nutrient_calculator.utils'],
    'scripts': ['bin/NutrientCalculator.py'],
    'name': 'nutrient_calculator'
}

setup(**config)
