"""Event class.

Attributes:
    None

Examples:
    Add later

Creation Date: 20 September 2016
Creator: Andres Kroker
"""

# -- imports --
import logging
from nutrient_calculator import Milk
from nutrient_calculator import ChocolateMilk
from nutrient_calculator import SoyMilkFort
from nutrient_calculator import OtherMilk
from nutrient_calculator import MilkShake
from nutrient_calculator import MilkCereal
from nutrient_calculator import MilkDessert
from nutrient_calculator import Yogurt
from nutrient_calculator import MilkCoffee
from nutrient_calculator import SoftCheese
from nutrient_calculator import HardCheese
from nutrient_calculator import WhiteBread
from nutrient_calculator import DarkBread
from nutrient_calculator import Chips
from nutrient_calculator import Waffle
from nutrient_calculator import Butter
from nutrient_calculator import Margarine
from nutrient_calculator import Tofu
from nutrient_calculator import Macaroni
from nutrient_calculator import CreamSoup
from nutrient_calculator import Salmon
from nutrient_calculator import Tuna
from nutrient_calculator import Sardine
from nutrient_calculator import SalmonSteak
from nutrient_calculator import WhiteFish
from nutrient_calculator import OilyFish
from nutrient_calculator import Meat
from nutrient_calculator import Taco
from nutrient_calculator import Pizza
from nutrient_calculator import Lentil
from nutrient_calculator import Egg
from nutrient_calculator import Potato
from nutrient_calculator import OrangeJuice
from nutrient_calculator import OrangeJuiceFort
from nutrient_calculator import Greens
from nutrient_calculator import Seafood
from nutrient_calculator import Bacon

# This class creates date objects from the strings we get from questionnaires
# required format yyyy-mm-dd


class Event(object):
    """Event class.

    An event is an 'entry' of the table.

    Class Level Attibutes:
        None

    __init__:
        None

    Examples:
        None
    """

    # class level Attributes

    def __init__(self, study_id, event_name):
        """doc string for __init__."""
        super(Event, self).__init__()
        self.study_id = study_id
        self.event_name = event_name
        self.vitD_total = None
        self.calc_total = None
        self.Milk = None
        self.ChocolateMilk = None
        self.SoyMilkFort = None
        self.OtherMilk = None
        self.MilkShake = None
        self.MilkCereal = None
        self.MilkDessert = None
        self.Yogurt = None
        self.MilkCoffee = None
        self.SoftCheese = None
        self.HardCheese = None
        self.WhiteBread = None
        self.DarkBread = None
        self.Chips = None
        self.Waffle = None
        self.Butter = None
        self.Margarine = None
        self.Tofu = None
        self.Macaroni = None
        self.CreamSoup = None
        self.Salmon = None
        self.Tuna = None
        self.Sardine = None
        self.SalmonSteak = None
        self.WhiteFish = None
        self.OilyFish = None
        self.Meat = None
        self.Taco = None
        self.Pizza = None
        self.Lentil = None
        self.Egg = None
        self.Potato = None
        self.OrangeJuice = None
        self.OrangeJuiceFort = None
        self.Greens = None
        self.Seafood = None
        self.Bacon = None
        self.complete = 1  # 0 if incomplete, 1 if complete.

    def total_nutrients(self):
        """calculate total nutrients."""
        if self.complete:
            try:
                vitD = [self.Milk.vitD_total,
                    self.ChocolateMilk.vitD_total,
                    self.SoyMilkFort.vitD_total,
                    self.OtherMilk.vitD_total,
                    self.MilkShake.vitD_total,
                    self.MilkCereal.vitD_total,
                    self.MilkDessert.vitD_total,
                    self.Yogurt.vitD_total,
                    self.MilkCoffee.vitD_total,
                    self.SoftCheese.vitD_total,
                    self.HardCheese.vitD_total,
                    self.WhiteBread.vitD_total,
                    self.DarkBread.vitD_total,
                    self.Chips.vitD_total,
                    self.Waffle.vitD_total,
                    self.Butter.vitD_total,
                    self.Margarine.vitD_total,
                    self.Tofu.vitD_total,
                    self.Macaroni.vitD_total,
                    self.CreamSoup.vitD_total,
                    self.Salmon.vitD_total,
                    self.Tuna.vitD_total,
                    self.Sardine.vitD_total,
                    self.SalmonSteak.vitD_total,
                    self.WhiteFish.vitD_total,
                    self.OilyFish.vitD_total,
                    self.Meat.vitD_total,
                    self.Taco.vitD_total,
                    self.Pizza.vitD_total,
                    self.Lentil.vitD_total,
                    self.Egg.vitD_total,
                    self.Potato.vitD_total,
                    self.OrangeJuice.vitD_total,
                    self.OrangeJuiceFort.vitD_total,
                    self.Greens.vitD_total,
                    self.Seafood.vitD_total,
                    self.Bacon.vitD_total]

                calc = [self.Milk.calc_total,
                    self.ChocolateMilk.calc_total,
                    self.SoyMilkFort.calc_total,
                    self.OtherMilk.calc_total,
                    self.MilkShake.calc_total,
                    self.MilkCereal.calc_total,
                    self.MilkDessert.calc_total,
                    self.Yogurt.calc_total,
                    self.MilkCoffee.calc_total,
                    self.SoftCheese.calc_total,
                    self.HardCheese.calc_total,
                    self.WhiteBread.calc_total,
                    self.DarkBread.calc_total,
                    self.Chips.calc_total,
                    self.Waffle.calc_total,
                    self.Butter.calc_total,
                    self.Margarine.calc_total,
                    self.Tofu.calc_total,
                    self.Macaroni.calc_total,
                    self.CreamSoup.calc_total,
                    self.Salmon.calc_total,
                    self.Tuna.calc_total,
                    self.Sardine.calc_total,
                    self.SalmonSteak.calc_total,
                    self.WhiteFish.calc_total,
                    self.OilyFish.calc_total,
                    self.Meat.calc_total,
                    self.Taco.calc_total,
                    self.Pizza.calc_total,
                    self.Lentil.calc_total,
                    self.Egg.calc_total,
                    self.Potato.calc_total,
                    self.OrangeJuice.calc_total,
                    self.OrangeJuiceFort.calc_total,
                    self.Greens.calc_total,
                    self.Seafood.calc_total,
                    self.Bacon.calc_total]

            except AttributeError:
                logging.error("one of the consumables has not yet been created for this event.")
            else:
                # calculate sum
                self.vitD_total = sum(vitD)
                self.calc_total = sum(calc)
                logging.debug("logging entry for study_id {id} and event {en}.".format(id=self.study_id, en=self.event_name))
        else:
            logging.warning("not all foods are added to this event. cannot process.")
