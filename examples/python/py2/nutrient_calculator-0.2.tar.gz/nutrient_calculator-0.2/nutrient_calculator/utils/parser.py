"""CSV classes.

Attributes:
    None

Examples:
    Add later

Creation Date: 17 September 2016
Creator: Andres Kroker
"""

# -- imports --
import logging
from nutrient_calculator import Event
from nutrient_calculator import Milk
from nutrient_calculator import ChocolateMilk
from nutrient_calculator import SoyMilkFort
from nutrient_calculator import SoyMilk
from nutrient_calculator import OtherMilk
from nutrient_calculator import MilkShake
from nutrient_calculator import MilkCereal
from nutrient_calculator import MilkDessert
from nutrient_calculator import Yogurt
from nutrient_calculator import MilkCoffee
from nutrient_calculator import SoftCheese
from nutrient_calculator import HardCheese
from nutrient_calculator import WhiteBread
from nutrient_calculator import DarkBread
from nutrient_calculator import Chips
from nutrient_calculator import Waffle
from nutrient_calculator import Butter
from nutrient_calculator import Margarine
from nutrient_calculator import Tofu
from nutrient_calculator import Macaroni
from nutrient_calculator import CreamSoup
from nutrient_calculator import Salmon
from nutrient_calculator import Tuna
from nutrient_calculator import Sardine
from nutrient_calculator import SalmonSteak
from nutrient_calculator import WhiteFish
from nutrient_calculator import OilyFish
from nutrient_calculator import Meat
from nutrient_calculator import Taco
from nutrient_calculator import Pizza
from nutrient_calculator import Lentil
from nutrient_calculator import Egg
from nutrient_calculator import Potato
from nutrient_calculator import OrangeJuice
from nutrient_calculator import OrangeJuiceFort
from nutrient_calculator import Greens
from nutrient_calculator import Seafood
from nutrient_calculator import Bacon

# This class creates date objects from the strings we get from questionnaires
# required format yyyy-mm-dd


class Parser(object):
    """Parser class.

    Class Level Attibutes:
        none

    __init__:
        None

    Examples:
        None
    """

    # class level attributes.
    header_types = []

    def __init__(self, path):
        """doc string for __init__."""
        super(Parser, self).__init__()
        pass

    # parse
    @classmethod
    def parse_row(cls, row, index):
        """parse_row the input text."""
        # setup parameters
        # milk
        milk_parser = cls.parse_entries()
        milk_parser.send(None)

        # chocolate_milk
        chocolate_milk_parser = cls.parse_entries()
        chocolate_milk_parser.send(None)

        # soy_fort
        soy_fort_parser = cls.parse_entries()
        soy_fort_parser.send(None)

        # soy
        soy_parser = cls.parse_entries()
        soy_parser.send(None)

        # other_milk
        other_milk_parser = cls.parse_entries()
        other_milk_parser.send(None)

        # milk_shake
        milk_shake_parser = cls.parse_entries()
        milk_shake_parser.send(None)

        # milk_cereal
        milk_cereal_parser = cls.parse_entries()
        milk_cereal_parser.send(None)

        # milk_dessert
        milk_dessert_parser = cls.parse_entries()
        milk_dessert_parser.send(None)

        # yogurt
        yogurt_parser = cls.parse_entries()
        yogurt_parser.send(None)

        # milk_coffee
        milk_coffee_parser = cls.parse_entries()
        milk_coffee_parser.send(None)

        # soft_cheese
        soft_cheese_parser = cls.parse_entries()
        soft_cheese_parser.send(None)

        # hard_cheese
        hard_cheese_parser = cls.parse_entries()
        hard_cheese_parser.send(None)

        # white_bread
        white_bread_parser = cls.parse_entries()
        white_bread_parser.send(None)

        # dark_bread
        dark_bread_parser = cls.parse_entries()
        dark_bread_parser.send(None)

        # chips
        chips_parser = cls.parse_entries()
        chips_parser.send(None)

        # waffle
        waffle_parser = cls.parse_entries()
        waffle_parser.send(None)

        # butter
        butter_parser = cls.parse_entries()
        butter_parser.send(None)

        # margarine
        margarine_parser = cls.parse_entries()
        margarine_parser.send(None)

        # tofu
        tofu_parser = cls.parse_entries()
        tofu_parser.send(None)

        # mac
        mac_parser = cls.parse_entries()
        mac_parser.send(None)

        # cream_soups
        cream_soups_parser = cls.parse_entries()
        cream_soups_parser.send(None)

        # salmon
        salmon_parser = cls.parse_entries()
        salmon_parser.send(None)

        # tuna
        tuna_parser = cls.parse_entries()
        tuna_parser.send(None)

        # sardines
        sardines_parser = cls.parse_entries()
        sardines_parser.send(None)

        # salmon_steak
        salmon_steak_parser = cls.parse_entries()
        salmon_steak_parser.send(None)

        # white_fish
        white_fish_parser = cls.parse_entries()
        white_fish_parser.send(None)

        # oily_fish
        oily_fish_parser = cls.parse_entries()
        oily_fish_parser.send(None)

        # meats
        meats_parser = cls.parse_entries()
        meats_parser.send(None)

        # taco
        taco_parser = cls.parse_entries()
        taco_parser.send(None)

        # pizza
        pizza_parser = cls.parse_entries()
        pizza_parser.send(None)

        # lentils
        lentils_parser = cls.parse_entries()
        lentils_parser.send(None)

        # eggs
        eggs_parser = cls.parse_entries()
        eggs_parser.send(None)

        # potatoes
        potatoes_parser = cls.parse_entries()
        potatoes_parser.send(None)

        # oj
        oj_parser = cls.parse_entries()
        oj_parser.send(None)

        # oj_fort
        oj_fort_parser = cls.parse_entries()
        oj_fort_parser.send(None)

        # greens
        greens_parser = cls.parse_entries()
        greens_parser.send(None)

        # seafood
        seafood_parser = cls.parse_entries()
        seafood_parser.send(None)

        # bacon
        bacon_parser = cls.parse_entries()
        bacon_parser.send(None)

        if index == 0:
            cls.parse_header(row)
            return
        else:
            # create emtpy consumables to be save
            portion = 11
            frq = 1
            milk = Milk(portion, frq)
            chocolate_milk = ChocolateMilk(portion, frq)
            soy_fort = SoyMilkFort(portion, frq)
            soy = SoyMilk(portion, frq)
            other_milk = OtherMilk(portion, frq)
            milk_shake = MilkShake(portion, frq)
            milk_cereal = MilkCereal(portion, frq)
            milk_dessert = MilkDessert(portion, frq)
            yogurt = Yogurt(portion, frq)
            milk_coffee = MilkCoffee(portion, frq)
            soft_cheese = SoftCheese(portion, frq)
            hard_cheese = HardCheese(portion, frq)
            white_bread = WhiteBread(portion, frq)
            dark_bread = DarkBread(portion, frq)
            chips = Chips(portion, frq)
            waffle = Waffle(portion, frq)
            butter = Butter(portion, frq)
            margarine = Margarine(portion, frq)
            tofu = Tofu(portion, frq)
            mac = Macaroni(portion, frq)
            cream_soups = CreamSoup(portion, frq)
            salmon = Salmon(portion, frq)
            tuna = Tuna(portion, frq)
            sardines = Sardine(portion, frq)
            salmon_steak = SalmonSteak(portion, frq)
            white_fish = WhiteFish(portion, frq)
            oily_fish = OilyFish(portion, frq)
            meats = Meat(portion, frq)
            taco = Taco(portion, frq)
            pizza = Pizza(portion, frq)
            lentils = Lentil(portion, frq)
            eggs = Egg(portion, frq)
            potatoes = Potato(portion, frq)
            oj = OrangeJuice(portion, frq)
            oj_fort = OrangeJuiceFort(portion, frq)
            greens = Greens(portion, frq)
            seafood = Seafood(portion, frq)
            bacon = Bacon(portion, frq)

            for index in range(len(row)-1):  # loop over row entries
                item, value = cls.header_types[index]  # get header and value
                entry = row[index]  # get entry value matching the header
                # assign entries to things
                if item == 'study_id':
                    study_id = entry
                elif item == 'redcap_event_name':
                    event_name = entry
                elif item == 'milk':
                    output = cls.extract_consumable(milk_parser, value, entry, Milk)
                    if output is None:
                        pass
                    else:
                        milk = output
                elif item == 'chocolate_milk':
                    output = cls.extract_consumable(chocolate_milk_parser, value, entry, ChocolateMilk)
                    if output is None:
                        pass
                    else:
                        chocolate_milk = output
                elif item == 'soy_fort':
                    output = cls.extract_consumable(soy_fort_parser, value, entry, SoyMilkFort)
                    if output is None:
                        pass
                    else:
                        soy_fort = output
                elif item == 'soy':
                    output = cls.extract_consumable(soy_parser, value, entry, SoyMilk)
                    if output is None:
                        pass
                    else:
                        soy = output
                elif item == 'other_milk':
                    output = cls.extract_consumable(other_milk_parser, value, entry, OtherMilk)
                    if output is None:
                        pass
                    else:
                        other_milk = output
                elif item == 'milk_shake':
                    output = cls.extract_consumable(milk_shake_parser, value, entry, MilkShake)
                    if output is None:
                        pass
                    else:
                        milk_shake = output
                elif item == 'milk_cereal':
                    output = cls.extract_consumable(milk_cereal_parser, value, entry, MilkCereal)
                    if output is None:
                        pass
                    else:
                        milk_cereal = output
                elif item == 'milk_dessert':
                    output = cls.extract_consumable(milk_dessert_parser, value, entry, MilkDessert)
                    if output is None:
                        pass
                    else:
                        milk_dessert = output
                elif item == 'yogurt':
                    output = cls.extract_consumable(yogurt_parser, value, entry, Yogurt)
                    if output is None:
                        pass
                    else:
                        yogurt = output
                elif item == 'milk_coffee':
                    output = cls.extract_consumable(milk_coffee_parser, value, entry, MilkCoffee)
                    if output is None:
                        pass
                    else:
                        milk_coffee = output
                elif item == 'soft_cheese':
                    output = cls.extract_consumable(soft_cheese_parser, value, entry, SoftCheese)
                    if output is None:
                        pass
                    else:
                        soft_cheese = output
                elif item == 'hard_cheese':
                    output = cls.extract_consumable(hard_cheese_parser, value, entry, HardCheese)
                    if output is None:
                        pass
                    else:
                        hard_cheese = output
                elif item == 'white_bread':
                    output = cls.extract_consumable(white_bread_parser, value, entry, WhiteBread)
                    if output is None:
                        pass
                    else:
                        white_bread = output
                elif item == 'dark_bread':
                    output = cls.extract_consumable(dark_bread_parser, value, entry, DarkBread)
                    if output is None:
                        pass
                    else:
                        dark_bread = output
                elif item == 'chips':
                    output = cls.extract_consumable(chips_parser, value, entry, Chips)
                    if output is None:
                        pass
                    else:
                        chips = output
                elif item == 'waffle':
                    output = cls.extract_consumable(waffle_parser, value, entry, Waffle)
                    if output is None:
                        pass
                    else:
                        waffle = output
                elif item == 'butter':
                    output = cls.extract_consumable(butter_parser, value, entry, Butter)
                    if output is None:
                        pass
                    else:
                        butter = output
                elif item == 'margarine':
                    output = cls.extract_consumable(margarine_parser, value, entry, Margarine)
                    if output is None:
                        pass
                    else:
                        margarine = output
                elif item == 'tofu':
                    output = cls.extract_consumable(tofu_parser, value, entry, Tofu)
                    if output is None:
                        pass
                    else:
                        tofu = output
                elif item == 'mac':
                    output = cls.extract_consumable(mac_parser, value, entry, Macaroni)
                    if output is None:
                        pass
                    else:
                        mac = output
                elif item == 'cream_soups':
                    output = cls.extract_consumable(cream_soups_parser, value, entry, CreamSoup)
                    if output is None:
                        pass
                    else:
                        cream_soups = output
                elif item == 'salmon':
                    output = cls.extract_consumable(salmon_parser, value, entry, Salmon)
                    if output is None:
                        pass
                    else:
                        salmon = output
                elif item == 'tuna':
                    output = cls.extract_consumable(tuna_parser, value, entry, Tuna)
                    if output is None:
                        pass
                    else:
                        tuna = output
                elif item == 'sardines':
                    output = cls.extract_consumable(sardines_parser, value, entry, Sardine)
                    if output is None:
                        pass
                    else:
                        sardines = output
                elif item == 'salmon_steak':
                    output = cls.extract_consumable(salmon_steak_parser, value, entry, SalmonSteak)
                    if output is None:
                        pass
                    else:
                        salmon_steak = output
                elif item == 'white_fish':
                    output = cls.extract_consumable(white_fish_parser, value, entry, WhiteFish)
                    if output is None:
                        pass
                    else:
                        white_fish = output
                elif item == 'oily_fish':
                    output = cls.extract_consumable(oily_fish_parser, value, entry, OilyFish)
                    if output is None:
                        pass
                    else:
                        oily_fish = output
                elif item == 'meats':
                    output = cls.extract_consumable(meats_parser, value, entry, Meat)
                    if output is None:
                        pass
                    else:
                        meats = output
                elif item == 'taco':
                    output = cls.extract_consumable(taco_parser, value, entry, Taco)
                    if output is None:
                        pass
                    else:
                        taco = output
                elif item == 'pizza':
                    output = cls.extract_consumable(pizza_parser, value, entry, Pizza)
                    if output is None:
                        pass
                    else:
                        pizza = output
                elif item == 'lentils':
                    output = cls.extract_consumable(lentils_parser, value, entry, Lentil)
                    if output is None:
                        pass
                    else:
                        lentils = output
                elif item == 'eggs':
                    output = cls.extract_consumable(eggs_parser, value, entry, Egg)
                    if output is None:
                        pass
                    else:
                        eggs = output
                elif item == 'potatoes':
                    output = cls.extract_consumable(potatoes_parser, value, entry, Potato)
                    if output is None:
                        pass
                    else:
                        potatoes = output
                elif item == 'oj':
                    output = cls.extract_consumable(oj_parser, value, entry, OrangeJuice)
                    if output is None:
                        pass
                    else:
                        oj = output
                elif item == 'oj_fort':
                    output = cls.extract_consumable(oj_fort_parser, value, entry, OrangeJuiceFort)
                    if output is None:
                        pass
                    else:
                        oj_fort = output
                elif item == 'greens':
                    output = cls.extract_consumable(greens_parser, value, entry, Greens)
                    if output is None:
                        pass
                    else:
                        greens = output
                elif item == 'seafood':
                    output = cls.extract_consumable(seafood_parser, value, entry, Seafood)
                    if output is None:
                        pass
                    else:
                        seafood = output
                elif item == 'bacon':
                    output = cls.extract_consumable(bacon_parser, value, entry, Bacon)
                    if output is None:
                        pass
                    else:
                        bacon = output

        # create event, add consumables, calculate total nutrients
        event = Event(study_id, event_name)
        event.Milk = milk
        event.ChocolateMilk = chocolate_milk
        event.SoyMilkFort = soy_fort
        event.SoyMilk = soy
        event.OtherMilk = other_milk
        event.MilkShake = milk_shake
        event.MilkCereal = milk_cereal
        event.MilkDessert = milk_dessert
        event.Yogurt = yogurt
        event.MilkCoffee = milk_coffee
        event.SoftCheese = soft_cheese
        event.HardCheese = hard_cheese
        event.WhiteBread = white_bread
        event.DarkBread = dark_bread
        event.Chips = chips
        event.Waffle = waffle
        event.Butter = butter
        event.Margarine = margarine
        event.Tofu = tofu
        event.Macaroni = mac
        event.CreamSoup = cream_soups
        event.Salmon = salmon
        event.Tuna = tuna
        event.Sardine = sardines
        event.SalmonSteak = salmon_steak
        event.WhiteFish = white_fish
        event.OilyFish = oily_fish
        event.Meat = meats
        event.Taco = taco
        event.Pizza = pizza
        event.Lentil = lentils
        event.Egg = eggs
        event.Potato = potatoes
        event.OrangeJuice = oj
        event.OrangeJuiceFort = oj_fort
        event.Greens = greens
        event.Seafood = seafood
        event.Bacon = bacon
        event.total_nutrients()
        return event

    @staticmethod
    def check(generator, value, entry):
        """check entry."""
        try:
            result = generator.send((int(value), int(entry)))
        except ValueError:
            pass
        except TypeError:
            pass
        except StopIteration:
            return None
        else:
            return result

    @classmethod
    def extract_consumable(cls, generator, value, entry, consumable):
        """check if tuple correct and create instance of consumable."""
        try:
            frq, portion = cls.check(generator, value, entry)
        except TypeError:
            pass
        else:  # if tuple, check if both entries filled
            if (frq is not None and portion is not None):
                return consumable(portion, frq)

    # parse header
    @classmethod
    def parse_header(cls, headers):
        """parse spreadsheet header.
        update list with tuple: (name, value) of consumable and.
        value in the top.
        """
        for header in headers:
            div = header.split('_')
            if len(div) < 5:
                item = '_'.join(div)
                value = None
            elif len(div) == 5:  # headers with single word
                item = div[1]
                value = div[-1]
            elif len(div) == 6:  # headers with 2 words and '_' between them
                temp = div[1:3]
                item = '_'.join(temp)
                value = div[-1]
            cls.header_types.append((item, value))

    # parse consumable
    @staticmethod
    def parse_entries():
        """identify frq and portion."""
        frq = None
        portion = None
        while (frq is None or portion is None):  # as long not both are found
            data = yield
            value, entry = data
            if entry == 0:  # if entry is 0 just move on
                continue
            elif entry == 1:  # if this entry contains data
                if value == 1:  # never (frq)
                    frq = value
                    portion = 11  # default
                elif (value >= 2 and value <= 9):  # frequency more than never
                    frq = value
                elif (value >= 10 and value <= 12):  # portion size
                    portion = value
        yield (frq, portion)
        return
