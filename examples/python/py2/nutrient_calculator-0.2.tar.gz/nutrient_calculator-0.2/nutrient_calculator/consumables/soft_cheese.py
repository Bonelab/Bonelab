"""Soft Cheese classes.

Attributes:
    name (str): name of diet
    vitD_daily (float): daily vitamin D content (assuming medium size)
    calc_daily (float): daily Calcium content (assuming medium size)

Examples:
    Add later

Creation Date: 16 September 2016
Creator: Andres Kroker
"""

# -- imports --
from nutrient_calculator import Consumable

# This class creates date objects from the strings we get from questionnaires
# required format yyyy-mm-dd


class SoftCheese(Consumable):
    """SoftCheese class.

    Class Level Attibutes:
        None

    __init__:
        None

    Examples:
        None
    """

    # class level Attributes
    name = 'soft_cheese'
    vitD_daily = 10.99
    calc_daily = 11.2

    def __init__(self, portion_id, frq):
        """doc string for __init__."""
        super(SoftCheese, self).__init__()
        self.init_vitD()
        self.init_calc()
        self.num2portion(portion_id)
        self.calculate_vitD(frq)
        self.calculate_calc(frq)
