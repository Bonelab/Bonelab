"""Consumable base classes.

Attributes:
    None

Examples:
    Add later

Creation Date: 16 September 2016
Creator: Andres Kroker
"""

# -- imports --
import logging

# This class creates date objects from the strings we get from questionnaires
# required format yyyy-mm-dd


class Consumable(object):
    """Consumable base class.

    Class Level Attibutes:
        name (str): name of diet
        vitD_unit (str): unit this is presented
        vitD_daily (float): daily vitamin D content (assuming medium size)
        vitD_weekly (float): weekly vitamin D content (assuming medium size)
        vitD_monthly (float): monthly vitamin D content (assuming medium size)
        vitD (dict): conversion of Laurens number of header to vitD amount
        calc_unit (str): unit this is presented
        calc_daily (float): daily Calcium content (assuming medium size)
        calc_weekly (float): weekly Calcium content (assuming medium size)
        calc_monthly (float): monthly Calcium content (assuming medium size)
        calc (dict): conversion of Laurens number of header to Calcium amount
        small (float): small weighting factor
        medium (float): medium weighting factor
        large (float): large weighting factor


    __init__:
        portion (str): portion size
        weighting (float): selected weighting factor of portion
        vitD_total (float): total vitD of diet for given portion and frequency
        calc_total (float): total calc of diet for given portion and frequency

    Examples:
        None
    """

    # class level Attributes
    name = None

    # portion weighting factors
    small = 0.5
    medium = 1.0
    large = 1.5

    # vitD amounts
    vitD_unit = None
    vitD_daily = 0.0
    vitD_weekly = None
    vitD_monthly = None
    vitD = None

    # calcium amounts
    calc_unit = None
    calc_daily = 0.0
    calc_weekly = None
    calc_monthly = None
    calc = None

    # sets all month to 0 as default if empty date is created
    def __init__(self):
        """doc string for __init__."""
        super(Consumable, self).__init__()
        self.portion = None
        self.weighting = None
        self.vitD_total = None
        self.calc_total = None

    # convert number to portion size
    def num2portion(self, portion_id):
        """convert portion ID to name."""
        if portion_id == 10:
            self.portion = 'small'
            self.weighting = self.small
        elif portion_id == 11:
            self.portion = 'medium'
            self.weighting = self.medium
        elif portion_id == 12:
            self.portion = 'large'
            self.weighting = self.large
        else:
            logging.warning('portion_id must be between 10 and 12')

    # calculate vitD
    def calculate_vitD(self, frequency):
        """calculate total vitD."""
        try:
            self.vitD_total = self.vitD[frequency] * self.weighting
        except KeyError:
            logging.exception('vitD: frequency {0} not valid'.format(frequency))

    # calculate vitD
    def calculate_calc(self, frequency):
        """calculate total calc."""
        try:
            self.calc_total = self.calc[frequency] * self.weighting
        except KeyError:
            logging.exception('calc: frequency {0} not valid'.format(frequency))

    # init vitD
    @classmethod
    def init_vitD(cls):
        """initialize vitD factors."""
        cls.vitD_weekly = cls.vitD_daily / 7.0
        cls.vitD_monthly = cls.vitD_daily / 30.0
        cls.vitD = {1: 0, 2: cls.vitD_monthly,
                    3: cls.vitD_monthly * 2.5,
                    4: cls.vitD_weekly,
                    5: cls.vitD_weekly * 2.0,
                    6: cls.vitD_weekly * 3.5,
                    7: cls.vitD_weekly * 5.5,
                    8: cls.vitD_daily,
                    9: cls.vitD_daily * 2.0
                    }
        logging.debug('calculating vitD for different frequencies with daily vitD of {0}'.format(cls.vitD_daily))

    # init calc
    @classmethod
    def init_calc(cls):
        """initialize vitD factors."""
        cls.calc_weekly = cls.calc_daily / 7.0
        cls.calc_monthly = cls.calc_daily / 30.0
        cls.calc = {1: 0, 2: cls.calc_monthly,
                    3: cls.calc_monthly * 2.5,
                    4: cls.calc_weekly,
                    5: cls.calc_weekly * 2.0,
                    6: cls.calc_weekly * 3.5,
                    7: cls.calc_weekly * 5.5,
                    8: cls.calc_daily,
                    9: cls.calc_daily * 2.0
                    }
        logging.debug('calculating Calcium for different frequencies with daily Calcium of {0}'.format(cls.calc_daily))
