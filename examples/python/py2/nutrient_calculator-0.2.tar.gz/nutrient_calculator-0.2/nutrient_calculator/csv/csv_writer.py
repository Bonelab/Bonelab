"""CSVWriter class.

Attributes:
    None

Examples:
    Add later

Creation Date: 23 September 2016
Creator: Andres Kroker
"""

# -- imports --
import logging
import csv
import os
from nutrient_calculator import Event
import time


# This class creates date objects from the strings we get from questionnaires
# required format yyyy-mm-dd


class CSVWriter(object):
    """CSVWriter class.

    Class Level Attibutes:
        none

    __init__:
        None

    Examples:
        None
    """

    # class level attributes.
    header_types = []

    def __init__(self, path, filename):
        """doc string for __init__."""
        super(CSVWriter, self).__init__()
        self.input_file = filename
        self.filename = None
        self.extension = None
        self.full_path = None
        self.directory = path
        self._file = None
        self.file = None

    def directory():
        """The full_path property."""
        def fget(self):
            return self._directory

        def fset(self, path):
            self._directory = os.path.abspath(path) + '/'
            basename, extension = self.input_file.split('.')
            self.filename = basename + '_results_' + time.strftime("%Y-%m-%d_%H-%M-%S")
            self.extension = '.csv'
            self.full_path = os.path.join(self.directory, (self.filename + self.extension))

        return locals()
    directory = property(**directory())

    # open file
    def open(self):
        """open file."""
        logging.info("opening output file: {0}".format(self.full_path))
        self._file = open(self.full_path, 'wb')
        self.file = csv.writer(self._file, dialect='excel', quoting=csv.QUOTE_ALL)
        self.init_header()

    def close(self):
        """close file."""
        logging.info("closing output file: {0}".format(self.full_path))
        self._file.close()

    def append(self, event):
        """append event to file."""
        if isinstance(event, Event):
            logging.info("id: {0}; event: {1}; total vitD: {2}; total calc: {3}.".format(event.study_id, event.event_name, event.vitD_total, event.calc_total))
            results = [event.study_id, event.event_name, event.vitD_total, event.calc_total]
            self.file.writerow(results)
        else:
            logging.info("not providing an event")

    def init_header(self):
        """create header of file."""
        header = ['study_id', 'event_name', 'vitD_total', 'calc_total']
        self.file.writerow(header)
