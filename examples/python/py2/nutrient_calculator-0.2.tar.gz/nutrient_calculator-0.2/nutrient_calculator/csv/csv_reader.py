"""CSV classes.

Attributes:
    None

Examples:
    Add later

Creation Date: 17 September 2016
Creator: Andres Kroker
"""

# -- imports --
import logging
import csv
import os
from nutrient_calculator import Parser
from nutrient_calculator import CSVWriter


# This class creates date objects from the strings we get from questionnaires
# required format yyyy-mm-dd


class CSVReader(object):
    """CSVReader class.

    Class Level Attibutes:
        none

    __init__:
        None

    Examples:
        None
    """

    # class level attributes.
    header_types = []

    def __init__(self, path):
        """doc string for __init__."""
        super(CSVReader, self).__init__()
        self.filename = None
        self.directory = None
        self.full_path = path
        self.file = None

    def full_path():
        """The full_path property."""
        def fget(self):
            return self._full_path

        def fset(self, path):
            self._full_path = os.path.abspath(path)
            directory, self.filename = os.path.split(self._full_path)
            self.directory = directory + '/'

        return locals()
    full_path = property(**full_path())

    # open TODO: add 'with' statement
    def open(self):
        """open in file."""
        # with open(self.full_path, 'rU') as text:
        #     self.file = csv.reader(text, dialect=csv.excel_tab)
        self._file = open(self.full_path, 'rU')
        self.file = csv.reader(self._file.read().splitlines())
        logging.info("opening input file {0}".format(self.full_path))

    def close(self):
        """close file."""
        self._file.close()
        logging.info("closing input file {0}".format(self.full_path))

    # reader
    def read(self):
        """read through the file."""
        for row in self.file:
            yield row

    # parse
    def parse(self, path):
        """parse file."""
        # new output file
        output = CSVWriter(path, self.filename)
        output.open()
        try:
            self.open()
            index = 0
            for row in self.read():
                if row:  # if row contains content --> process it
                    logging.debug("parsing row {0}".format(index))
                    event = Parser.parse_row(row, index)
                    if event is not None:
                        output.append(event)
                    index += 1
                else:  # if the row is empty --> skip it.
                    logging.debug("row {0} is empty.".format(index))
                    continue
        except StopIteration:
            logging.debug("done logging file {0}".format(self.filename))
        finally:
            self.close()
            output.close()
